# HiveTech Deployment Guide

This guide details how to deploy the **HiveTech** application to **GitHub Pages**.

Since the application uses React, TypeScript, and Environment Variables (for the Gemini API Key), we recommend using **Vite** for building and bundling the application.

---

## Prerequisites

1.  **Node.js** (v18 or higher) installed.
2.  A **GitHub Account**.
3.  **Git** installed.

---

## Phase 1: Initialize a Vite Project

The current file structure is designed for a direct browser/CDN environment. To deploy effectively, we will scaffold a production-ready build environment.

1.  Open your terminal.
2.  Create a new Vite project:
    ```bash
    npm create vite@latest hivetech -- --template react-ts
    cd hivetech
    npm install
    ```
3.  Install necessary dependencies used in the app:
    ```bash
    npm install @google/genai lucide-react recharts tailwindcss postcss autoprefixer
    ```
4.  Initialize Tailwind CSS:
    ```bash
    npx tailwindcss init -p
    ```

---

## Phase 2: Migrate Files

Move the existing files into the new `hivetech` folder structure:

1.  **Tailwind Config**: Update `tailwind.config.js` in the root:
    ```javascript
    export default {
      content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
      ],
      theme: {
        extend: {},
      },
      plugins: [],
    }
    ```
2.  **Styles**: Replace the contents of `src/index.css` with:
    ```css
    @tailwind base;
    @tailwind components;
    @tailwind utilities;
    
    /* Add the custom styles from the original index.html style tag here */
    .no-scrollbar::-webkit-scrollbar {
        display: none;
    }
    /* ... rest of custom css */
    ```
3.  **Source Code**:
    *   Copy `App.tsx`, `types.ts`, and `constants.ts` into `src/`.
    *   Create folders `src/components`, `src/screens`, `src/services`.
    *   Move the respective component files into these folders.
    *   Update `src/main.tsx` (Vite's entry point) to import `App`:
        ```tsx
        import React from 'react'
        import ReactDOM from 'react-dom/client'
        import App from './App.tsx'
        import './index.css'

        ReactDOM.createRoot(document.getElementById('root')!).render(
          <React.StrictMode>
            <App />
          </React.StrictMode>,
        )
        ```

---

## Phase 3: Handling the API Key

The application uses `process.env.API_KEY`. Vite exposes variables via `import.meta.env`, but to keep the code unchanged, we will configure Vite to define the global constant.

1.  Open `vite.config.ts`.
2.  Update it to look like this:

    ```typescript
    import { defineConfig, loadEnv } from 'vite'
    import react from '@vitejs/plugin-react'

    export default defineConfig(({ mode }) => {
      const env = loadEnv(mode, process.cwd(), '');
      return {
        plugins: [react()],
        define: {
          'process.env.API_KEY': JSON.stringify(env.API_KEY)
        },
        base: '/hivetech/', // IMPORTANT: Replace 'hivetech' with your repo name
      }
    })
    ```

3.  **Local Development**: Create a `.env` file in the root:
    ```env
    API_KEY=your_actual_gemini_api_key_here
    ```
    *Note: Add `.env` to your `.gitignore` file to prevent leaking your key.*

---

## Phase 4: Push to GitHub

1.  Initialize Git in your `hivetech` folder:
    ```bash
    git init
    git add .
    git commit -m "Initial commit"
    ```
2.  Create a new repository on GitHub.
3.  Link and push:
    ```bash
    git remote add origin https://github.com/YOUR_USERNAME/hivetech.git
    git push -u origin main
    ```

---

## Phase 5: Automated Deployment (GitHub Actions)

We will use GitHub Actions to build and deploy the site automatically.

1.  In your project, create the directory path: `.github/workflows/`.
2.  Create a file named `deploy.yml` inside that folder:

    ```yaml
    name: Deploy to GitHub Pages

    on:
      push:
        branches: [ main ]

    permissions:
      contents: write

    jobs:
      build-and-deploy:
        runs-on: ubuntu-latest
        steps:
          - name: Checkout
            uses: actions/checkout@v4

          - name: Set up Node
            uses: actions/setup-node@v4
            with:
              node-version: 20

          - name: Install dependencies
            run: npm ci

          - name: Build
            run: npm run build
            env:
              # This pulls the key from GitHub Secrets and embeds it in the build
              API_KEY: ${{ secrets.GEMINI_API_KEY }}

          - name: Deploy
            uses: JamesIves/github-pages-deploy-action@v4
            with:
              folder: dist
    ```

3.  **Set the Secret**:
    *   Go to your GitHub Repository Settings > **Secrets and variables** > **Actions**.
    *   Click **New repository secret**.
    *   Name: `GEMINI_API_KEY`
    *   Value: Paste your Google Gemini API Key.

4.  **Deploy**:
    *   Commit and push the workflow file:
        ```bash
        git add .github/workflows/deploy.yml
        git commit -m "Add deployment workflow"
        git push
        ```
    *   Go to the **Actions** tab in your repo to watch the build.
    *   Once green, go to **Settings** > **Pages** and ensure the source is set to `gh-pages` branch.

Your app will be live at `https://<YOUR_USERNAME>.github.io/hivetech/`.

---

## Important Note on API Security

By deploying a frontend-only application, your API Key will be embedded in the JavaScript bundle. While `process.env` hides it from the source code, it is technically visible in the network tab or minified code.

For a production enterprise application, it is recommended to set up a backend proxy (e.g., using Firebase Functions or Cloud Run) to hide the API key.
