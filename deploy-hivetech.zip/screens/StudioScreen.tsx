
import React, { useState, useRef } from 'react';
import { generateMarketingVideo } from '../services/geminiService';
import { Upload, Video, Loader2, Sparkles, Play, Film, AlertCircle, Image as ImageIcon, RefreshCw } from 'lucide-react';

export const StudioScreen: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoadingSample, setIsLoadingSample] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setError(null);
        setVideoUrl(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUseSample = async () => {
    setIsLoadingSample(true);
    setError(null);
    setVideoUrl(null);
    try {
        // Fetch a random tech/office related image
        const response = await fetch('https://picsum.photos/1280/720'); 
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
            setImage(reader.result as string);
            setIsLoadingSample(false);
        };
        reader.readAsDataURL(blob);
    } catch (e) {
        setError("Could not load sample image. Please upload one instead.");
        setIsLoadingSample(false);
    }
  };

  const handleGenerate = async () => {
    if (!image) return;
    setIsGenerating(true);
    setError(null);
    setVideoUrl(null);

    try {
      const url = await generateMarketingVideo(image, prompt, aspectRatio);
      setVideoUrl(url);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to generate video. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Creator Studio</h1>
        <p className="text-slate-500">Transform workspace photos into cinematic videos with Veo.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* INPUT SECTION */}
        <div className="space-y-6">
          {/* Image Upload Area */}
          <div 
            className={`
              relative h-64 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center transition-all overflow-hidden group
              ${image ? 'border-teal-500 bg-slate-900' : 'border-slate-300 bg-slate-50'}
            `}
          >
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleImageUpload} 
              accept="image/*" 
              className="hidden" 
            />
            
            {isLoadingSample ? (
                <div className="flex flex-col items-center text-slate-400">
                    <Loader2 size={32} className="animate-spin mb-2" />
                    <span className="text-sm">Fetching sample...</span>
                </div>
            ) : image ? (
              <>
                <img src={image} alt="Preview" className="w-full h-full object-contain opacity-80" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-sm">
                  <div className="flex gap-2">
                     <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="bg-white text-slate-900 px-4 py-2 rounded-xl font-bold text-sm hover:bg-slate-100 transition-colors flex items-center gap-2"
                     >
                        <Upload size={16} /> Replace
                     </button>
                     <button 
                        onClick={() => { setImage(null); setVideoUrl(null); }}
                        className="bg-slate-900 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-slate-800 transition-colors flex items-center gap-2 border border-slate-700"
                     >
                        <RefreshCw size={16} /> Clear
                     </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center p-6 space-y-4">
                <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="cursor-pointer group/upload"
                >
                    <div className="w-16 h-16 bg-white rounded-full shadow-sm flex items-center justify-center mx-auto mb-4 text-teal-600 group-hover/upload:scale-110 transition-transform">
                    <Upload size={24} />
                    </div>
                    <h3 className="font-bold text-slate-700">Upload a Photo</h3>
                    <p className="text-xs text-slate-500 mt-1">JPG or PNG (Max 5MB)</p>
                </div>
                
                <div className="flex items-center justify-center gap-2 text-xs text-slate-400">
                    <span className="h-px w-8 bg-slate-300"></span>
                    <span>OR</span>
                    <span className="h-px w-8 bg-slate-300"></span>
                </div>

                <button 
                    onClick={handleUseSample}
                    className="text-teal-600 hover:text-teal-700 font-bold text-xs flex items-center justify-center gap-1 mx-auto bg-teal-50 px-3 py-1.5 rounded-lg border border-teal-100 transition-colors"
                >
                    <ImageIcon size={14} /> Use Random Sample
                </button>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 space-y-4">
             <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Motion Prompt (Optional)</label>
                <textarea 
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe the movement (e.g., 'Slow camera pan right, cinematic lighting, 4k')"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-teal-500 outline-none resize-none h-24"
                />
             </div>

             <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Aspect Ratio</label>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setAspectRatio('16:9')}
                    className={`flex-1 py-3 rounded-xl text-sm font-bold border transition-all flex items-center justify-center gap-2 ${
                      aspectRatio === '16:9' ? 'bg-slate-900 text-white border-slate-900 shadow-md' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="w-6 h-3.5 border-2 border-current rounded-sm"></div> Landscape
                  </button>
                  <button 
                    onClick={() => setAspectRatio('9:16')}
                    className={`flex-1 py-3 rounded-xl text-sm font-bold border transition-all flex items-center justify-center gap-2 ${
                      aspectRatio === '9:16' ? 'bg-slate-900 text-white border-slate-900 shadow-md' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="w-3.5 h-6 border-2 border-current rounded-sm"></div> Portrait
                  </button>
                </div>
             </div>

             <button 
                onClick={handleGenerate}
                disabled={!image || isGenerating}
                className="w-full bg-gradient-to-r from-teal-600 to-teal-500 hover:from-teal-700 hover:to-teal-600 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-teal-500/20 active:scale-95"
             >
                {isGenerating ? (
                  <><Loader2 size={20} className="animate-spin" /> Generating Video...</>
                ) : (
                  <><Sparkles size={20} /> Generate AI Video</>
                )}
             </button>
             
             {error && (
               <div className={`flex items-start gap-2 text-xs p-3 rounded-xl border transition-all animate-in slide-in-from-top-2 ${
                 error.includes("Action Required") 
                   ? "text-amber-700 bg-amber-50 border-amber-200" 
                   : "text-red-600 bg-red-50 border-red-100"
               }`}>
                 {error.includes("Action Required") 
                    ? <RefreshCw size={14} className="mt-0.5 shrink-0" /> 
                    : <AlertCircle size={14} className="mt-0.5 shrink-0" />
                 }
                 <span>{error}</span>
               </div>
             )}
          </div>
        </div>

        {/* OUTPUT SECTION */}
        <div className="bg-slate-900 rounded-3xl overflow-hidden shadow-2xl relative min-h-[400px] flex items-center justify-center border border-slate-800">
            {isGenerating ? (
              <div className="text-center px-8 relative z-10">
                 <div className="w-20 h-20 border-4 border-teal-500/30 border-t-teal-500 rounded-full animate-spin mx-auto mb-6"></div>
                 <h3 className="text-white font-bold text-xl mb-2 animate-pulse">Creating Magic...</h3>
                 <p className="text-slate-400 text-sm max-w-[200px] mx-auto">We're generating high-quality frames. This may take about a minute.</p>
              </div>
            ) : videoUrl ? (
               <div className="relative w-full h-full bg-black flex items-center justify-center group">
                  <video 
                    src={videoUrl} 
                    controls 
                    autoPlay 
                    loop 
                    className="max-h-full max-w-full rounded-lg shadow-2xl"
                  />
               </div>
            ) : (
               <div className="text-center text-slate-700">
                  <Film size={64} className="mx-auto mb-4 opacity-20" />
                  <p className="text-sm font-medium">Your generated video will appear here.</p>
               </div>
            )}
            
            {/* Background decoration */}
            {!videoUrl && !isGenerating && (
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5 pointer-events-none"></div>
            )}
            
            {isGenerating && (
               <div className="absolute inset-0 bg-teal-500/5 animate-pulse pointer-events-none"></div>
            )}
        </div>
      </div>
    </div>
  );
};
