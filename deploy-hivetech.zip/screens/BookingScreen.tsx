
import React, { useState } from 'react';
import { Space } from '../types';
import { MOCK_SPACES } from '../constants';
import { BookingCard } from '../components/BookingCard';
import { FloorPlan } from '../components/FloorPlan';
import { Search, SlidersHorizontal, Map, LayoutGrid } from 'lucide-react';

export const BookingScreen: React.FC = () => {
  const [filter, setFilter] = useState('ALL');
  const [viewMode, setViewMode] = useState<'GRID' | 'MAP'>('GRID');
  
  const filteredSpaces = filter === 'ALL' 
    ? MOCK_SPACES 
    : MOCK_SPACES.filter(s => s.type === filter);

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 bg-slate-50/95 backdrop-blur-sm z-10 py-4">
        <div className="flex justify-between items-end mb-4">
            <h1 className="text-2xl font-bold text-slate-900">Find Space</h1>
            
            {/* View Toggle */}
            <div className="bg-white border border-slate-200 p-1 rounded-xl flex shadow-sm">
                <button 
                    onClick={() => setViewMode('GRID')}
                    className={`p-2 rounded-lg transition-all ${viewMode === 'GRID' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
                >
                    <LayoutGrid size={18} />
                </button>
                <button 
                    onClick={() => setViewMode('MAP')}
                    className={`p-2 rounded-lg transition-all ${viewMode === 'MAP' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
                >
                    <Map size={18} />
                </button>
            </div>
        </div>
        
        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by location or capacity..." 
              className="w-full bg-white border border-slate-200 pl-10 pr-4 py-2.5 rounded-xl text-sm focus:ring-2 focus:ring-teal-500 outline-none shadow-sm"
            />
          </div>
          <button className="bg-white border border-slate-200 p-2.5 rounded-xl shadow-sm">
            <SlidersHorizontal size={20} className="text-slate-600" />
          </button>
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
          {['ALL', 'MEETING_ROOM', 'HOT_DESK', 'PRIVATE_SUITE'].map((type) => (
            <button
              key={type}
              onClick={() => setFilter(type)}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-xs font-medium transition-colors ${
                filter === type 
                  ? 'bg-slate-900 text-white' 
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {type.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="animate-in fade-in duration-300">
        {viewMode === 'MAP' ? (
            <FloorPlan />
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredSpaces.map(space => (
                <BookingCard 
                    key={space.id} 
                    space={space} 
                    onBook={(s) => alert(`Booking flow for ${s.name} would open here.`)} 
                />
                ))}
            </div>
        )}
      </div>

      {/* Map Hint (Only show in Grid mode) */}
      {viewMode === 'GRID' && (
        <div className="bg-teal-50 rounded-2xl p-4 flex items-center justify-between border border-teal-100 cursor-pointer hover:bg-teal-100 transition-colors" onClick={() => setViewMode('MAP')}>
            <div className="flex items-center gap-3">
            <div className="bg-teal-100 p-2 rounded-full text-teal-700">
                <Map size={20} />
            </div>
            <div>
                <div className="font-medium text-teal-900">View Interactive Map</div>
                <div className="text-xs text-teal-600">See real-time availability nearby</div>
            </div>
            </div>
            <button className="text-sm font-bold text-teal-700">Open</button>
        </div>
      )}
    </div>
  );
};
