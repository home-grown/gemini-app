import React, { useState } from 'react';
import { MOCK_EVENTS, MOCK_COMMUNITY, MOCK_TEAM } from '../constants';
import { Calendar, Users, MapPin, MessageCircle, Plus, Search, UserPlus, ChevronLeft, ChevronRight, CalendarDays } from 'lucide-react';

export const CommunityScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'EVENTS' | 'NETWORK' | 'TEAM'>('EVENTS');
  const [viewMode, setViewMode] = useState<'LIST' | 'CALENDAR'>('LIST');

  // Dynamic Date Logic
  const today = new Date();
  const currentMonthName = today.toLocaleString('default', { month: 'long' });
  const currentMonthShort = today.toLocaleString('default', { month: 'short' });
  const currentYear = today.getFullYear();
  const daysInMonth = new Date(currentYear, today.getMonth() + 1, 0).getDate();

  const generateCalendarDays = () => {
    const days = [];
    for (let i = 1; i <= daysInMonth; i++) {
        days.push(i);
    }
    return days;
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Partner & Opportunities</h1>
        <p className="text-slate-500">Connect, collaborate, and grow with peers.</p>
      </div>

      {/* Tabs */}
      <div className="flex bg-white p-1 rounded-xl border border-slate-200 w-full max-w-md shadow-sm">
        <button
          onClick={() => setActiveTab('EVENTS')}
          className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'EVENTS' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Events
        </button>
        <button
          onClick={() => setActiveTab('NETWORK')}
          className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'NETWORK' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Partners
        </button>
        <button
          onClick={() => setActiveTab('TEAM')}
          className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'TEAM' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Team
        </button>
      </div>

      {/* EVENTS TAB */}
      {activeTab === 'EVENTS' && (
        <div className="animate-in slide-in-from-bottom-2 duration-300 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-2">
            <h2 className="font-bold text-lg">Networking Events Calendar</h2>
            
            <div className="flex gap-2">
                 <div className="bg-slate-100 p-1 rounded-lg flex">
                    <button 
                        onClick={() => setViewMode('LIST')}
                        className={`p-1.5 rounded-md transition-all ${viewMode === 'LIST' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                        <Users size={16} />
                    </button>
                    <button 
                         onClick={() => setViewMode('CALENDAR')}
                         className={`p-1.5 rounded-md transition-all ${viewMode === 'CALENDAR' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                        <CalendarDays size={16} />
                    </button>
                 </div>
                 <button className="flex items-center gap-1 bg-teal-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-teal-700 transition-colors">
                    <Plus size={14} /> Host Event
                 </button>
            </div>
          </div>

          {viewMode === 'CALENDAR' ? (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                  {/* Calendar Header */}
                  <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                      <h3 className="font-bold text-slate-900">{currentMonthName} {currentYear}</h3>
                      <div className="flex gap-1">
                          <button className="p-1 hover:bg-slate-200 rounded-md text-slate-500"><ChevronLeft size={16}/></button>
                          <button className="p-1 hover:bg-slate-200 rounded-md text-slate-500"><ChevronRight size={16}/></button>
                      </div>
                  </div>
                  
                  {/* Calendar Grid */}
                  <div className="p-4">
                      <div className="grid grid-cols-7 gap-2 text-center mb-2">
                          {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
                              <div key={d} className="text-xs font-bold text-slate-400 uppercase">{d}</div>
                          ))}
                      </div>
                      <div className="grid grid-cols-7 gap-2">
                          {generateCalendarDays().map(day => {
                              // Check MOCK_EVENTS for this day. 
                              // Mock Format: "Mmm D" (e.g. "Oct 24")
                              const dateString = `${currentMonthShort} ${day}`;
                              const eventForDay = MOCK_EVENTS.find(e => e.date === dateString);
                              const hasEvent = !!eventForDay;

                              return (
                                  <div key={day} className={`
                                      aspect-square rounded-xl flex flex-col items-start justify-start p-1 relative group cursor-pointer border
                                      ${hasEvent ? 'bg-teal-50 border-teal-100' : 'bg-white border-transparent hover:border-slate-100 hover:bg-slate-50'}
                                  `}>
                                      <span className={`text-xs font-medium ${hasEvent ? 'text-teal-700' : 'text-slate-600'}`}>{day}</span>
                                      {hasEvent && (
                                          <div className="mt-auto w-full">
                                              <div className="h-1.5 w-1.5 rounded-full bg-teal-500 mb-0.5"></div>
                                              <div className="hidden sm:block text-[8px] leading-tight text-teal-800 truncate w-full">
                                                  {eventForDay.title}
                                              </div>
                                          </div>
                                      )}
                                  </div>
                              );
                          })}
                      </div>
                  </div>
                  <div className="p-3 bg-slate-50 text-xs text-center text-slate-500 border-t border-slate-100">
                      {MOCK_EVENTS.length} events scheduled this month
                  </div>
              </div>
          ) : (
            <div className="grid gap-4">
                {MOCK_EVENTS.map(event => (
                <div key={event.id} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex gap-4 hover:shadow-md transition-shadow group">
                    <div className="w-24 h-24 shrink-0 rounded-xl overflow-hidden relative">
                    <img src={event.image} alt={event.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute top-0 left-0 bg-slate-900/80 text-white px-2 py-0.5 rounded-br-lg text-[10px] font-bold">
                        {event.date}
                    </div>
                    </div>
                    <div className="flex-1 flex flex-col justify-between">
                    <div>
                        <h3 className="font-bold text-slate-900 leading-tight">{event.title}</h3>
                        <div className="flex items-center gap-1 text-xs text-slate-500 mt-1">
                        <MapPin size={12} /> {event.location}
                        </div>
                    </div>
                    <div className="flex justify-between items-end mt-2">
                        <div className="flex gap-1">
                        {event.tags.map(tag => (
                            <span key={tag} className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full text-[10px] font-medium">
                            {tag}
                            </span>
                        ))}
                        </div>
                        <button className="text-teal-600 font-bold text-xs bg-teal-50 px-3 py-1.5 rounded-lg hover:bg-teal-100 transition-colors">
                        RSVP
                        </button>
                    </div>
                    </div>
                </div>
                ))}
            </div>
          )}
        </div>
      )}

      {/* NETWORK TAB */}
      {activeTab === 'NETWORK' && (
        <div className="animate-in slide-in-from-bottom-2 duration-300 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-2 flex gap-2">
            <Search className="text-slate-400 ml-2" size={20} />
            <input 
              placeholder="Find skills, companies, or people..." 
              className="flex-1 outline-none text-sm bg-transparent"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MOCK_COMMUNITY.map(member => (
              <div key={member.id} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 hover:border-teal-200 transition-colors relative overflow-hidden group">
                {member.isOnline && (
                  <div className="absolute top-4 right-4 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                )}
                <div className="flex items-start gap-4">
                  <img src={member.avatar} alt={member.name} className="w-14 h-14 rounded-full object-cover border-2 border-slate-50" />
                  <div>
                    <h3 className="font-bold text-slate-900">{member.name}</h3>
                    <p className="text-xs text-slate-500">{member.role} @ {member.company}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {member.skills.slice(0, 3).map(skill => (
                        <span key={skill} className="text-[10px] bg-slate-50 text-slate-600 px-2 py-0.5 rounded-md border border-slate-100">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex gap-2">
                  <button className="flex-1 bg-slate-900 text-white text-xs font-bold py-2 rounded-lg hover:bg-slate-800 transition-colors flex items-center justify-center gap-2">
                    <MessageCircle size={14} /> Chat
                  </button>
                  <button className="px-3 bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition-colors">
                    <UserPlus size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TEAM TAB (Original content) */}
      {activeTab === 'TEAM' && (
        <div className="animate-in slide-in-from-bottom-2 duration-300 space-y-4">
           <div className="bg-white rounded-2xl p-2 border border-slate-100 shadow-sm">
             {MOCK_TEAM.map((member) => (
               <div key={member.id} className="flex items-center justify-between p-4 hover:bg-slate-50 rounded-xl transition-colors border-b border-slate-50 last:border-0">
                  <div className="flex items-center gap-4">
                     <div className="relative">
                        <img src={member.avatar} alt={member.name} className="w-12 h-12 rounded-full object-cover" />
                        <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-white ${
                          member.status === 'IN_OFFICE' ? 'bg-green-500' :
                          member.status === 'REMOTE' ? 'bg-amber-500' : 'bg-slate-300'
                        }`}></div>
                     </div>
                     <div>
                        <div className="font-bold text-slate-900">{member.name}</div>
                        <div className="text-xs text-slate-500">{member.role}</div>
                     </div>
                  </div>
                  <div className="flex gap-2">
                     <button className="p-2 text-slate-400 hover:text-teal-600 hover:bg-teal-50 rounded-lg transition-colors">
                        <MessageCircle size={18} />
                     </button>
                  </div>
               </div>
             ))}
           </div>
           
           <div className="bg-teal-50 border border-teal-100 rounded-xl p-4 flex justify-between items-center">
             <div>
               <h4 className="font-bold text-teal-900 text-sm">Grow your team?</h4>
               <p className="text-xs text-teal-700">Add seats to your subscription instantly.</p>
             </div>
             <button className="bg-teal-600 text-white text-xs font-bold px-4 py-2 rounded-lg hover:bg-teal-700">
               Add Members
             </button>
           </div>
        </div>
      )}
    </div>
  );
};