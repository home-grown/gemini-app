import React from 'react';
import { View, Booking, TeamMember } from '../types';
import { Clock, MapPin, QrCode, ArrowUpRight, Zap, Users } from 'lucide-react';

interface DashboardProps {
  onNavigate: (view: View) => void;
  bookings: Booking[];
  team: TeamMember[];
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate, bookings, team }) => {
  const nextBooking = bookings.find(b => b.status === 'UPCOMING');
  const activeTeam = team.filter(t => t.status === 'IN_OFFICE');

  return (
    <div className="space-y-8 pb-24 md:pb-8">
      {/* Header */}
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Good Morning, Adrian</h1>
          <p className="text-slate-500 mt-1">Ready to scale today?</p>
        </div>
        <button 
          onClick={() => onNavigate(View.ACCESS)}
          className="bg-amber-400 hover:bg-amber-500 text-slate-900 p-3 rounded-2xl shadow-lg shadow-amber-400/20 transition-transform hover:-translate-y-1 active:scale-95"
        >
          <QrCode size={24} />
        </button>
      </div>

      {/* Hero Card: Upcoming */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500 rounded-full blur-[100px] opacity-20 translate-x-1/2 -translate-y-1/2"></div>
        
        <h2 className="text-sm font-medium text-slate-400 mb-4 uppercase tracking-wider">Up Next</h2>
        
        {nextBooking ? (
          <div>
             <div className="flex items-start justify-between">
                <div>
                   <h3 className="text-2xl font-bold mb-1">{nextBooking.spaceName}</h3>
                   <div className="flex items-center gap-2 text-slate-300">
                      <MapPin size={16} />
                      <span>HiveFlex CBD</span>
                   </div>
                </div>
                <div className="text-right">
                   <div className="text-2xl font-bold font-mono">{nextBooking.startTime}</div>
                   <div className="text-slate-400 text-sm">{nextBooking.date}</div>
                </div>
             </div>
             
             <div className="mt-6 flex gap-3">
               <button className="flex-1 bg-white/10 hover:bg-white/20 backdrop-blur-md py-2 px-4 rounded-xl text-sm font-medium transition-colors">
                  Edit Details
               </button>
               <button className="flex-1 bg-teal-600 hover:bg-teal-500 py-2 px-4 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2">
                  Check In <ArrowUpRight size={16} />
               </button>
             </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-slate-400">No upcoming bookings.</p>
            <button onClick={() => onNavigate(View.BOOKING)} className="text-teal-400 font-medium mt-2">Book a space</button>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <button 
          onClick={() => onNavigate(View.BOOKING)}
          className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 hover:border-teal-500 hover:shadow-md transition-all text-left group"
        >
          <div className="bg-teal-50 w-10 h-10 rounded-full flex items-center justify-center text-teal-600 mb-3 group-hover:scale-110 transition-transform">
            <Zap size={20} />
          </div>
          <div className="font-semibold text-slate-900">Quick Book</div>
          <div className="text-xs text-slate-500 mt-1">Repeat last booking</div>
        </button>

        <button 
          onClick={() => onNavigate(View.ACCESS)}
          className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 hover:border-teal-500 hover:shadow-md transition-all text-left group"
        >
           <div className="bg-purple-50 w-10 h-10 rounded-full flex items-center justify-center text-purple-600 mb-3 group-hover:scale-110 transition-transform">
            <Users size={20} />
          </div>
          <div className="font-semibold text-slate-900">Invite Guest</div>
          <div className="text-xs text-slate-500 mt-1">Send QR pass</div>
        </button>
      </div>

      {/* Team Status */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-bold text-lg">Team Pulse</h2>
          <span className="text-xs font-medium text-teal-600 bg-teal-50 px-2 py-1 rounded-lg">
            {activeTeam.length} In Office
          </span>
        </div>
        <div className="bg-white rounded-2xl p-2 border border-slate-100 shadow-sm">
          {team.map((member) => (
             <div key={member.id} className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-xl transition-colors">
                <div className="flex items-center gap-3">
                   <div className="relative">
                      <img src={member.avatar} alt={member.name} className="w-10 h-10 rounded-full object-cover" />
                      <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                        member.status === 'IN_OFFICE' ? 'bg-green-500' :
                        member.status === 'REMOTE' ? 'bg-amber-500' : 'bg-slate-300'
                      }`}></div>
                   </div>
                   <div>
                      <div className="font-medium text-sm text-slate-900">{member.name}</div>
                      <div className="text-xs text-slate-500">{member.role}</div>
                   </div>
                </div>
                <div className="text-xs font-medium text-slate-400">
                  {member.status === 'IN_OFFICE' ? 'Hive CBD' : member.status}
                </div>
             </div>
          ))}
        </div>
      </div>
    </div>
  );
};
