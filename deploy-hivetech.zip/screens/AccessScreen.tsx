import React, { useState } from 'react';
import { Wifi, Copy, Share2, Clock, X, User, Mail, CheckCircle2, Loader2, Sparkles } from 'lucide-react';

export const AccessScreen: React.FC = () => {
  const [showGuestModal, setShowGuestModal] = useState(false);
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [duration, setDuration] = useState('4h');
  const [status, setStatus] = useState<'IDLE' | 'SENDING' | 'SUCCESS'>('IDLE');

  const handleSendInvite = async () => {
    setStatus('SENDING');
    // Simulate API delay for "Fast AI" feel (but not actually using AI here for the form)
    await new Promise(resolve => setTimeout(resolve, 1200));
    setStatus('SUCCESS');
    
    // Auto close after success
    setTimeout(() => {
        setShowGuestModal(false);
        // Reset form
        setTimeout(() => {
            setStatus('IDLE');
            setGuestName('');
            setGuestEmail('');
            setDuration('4h');
        }, 300);
    }, 2500);
  };

  return (
    <div className="flex flex-col h-full space-y-6 pb-24 md:pb-8 relative">
      <div>
         <h1 className="text-2xl font-bold text-slate-900">Digital Access</h1>
         <p className="text-slate-500">Scan to enter any HiveFlex location.</p>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center">
         {/* Pass Card */}
         <div className="w-full max-w-sm bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-slate-100 relative group transition-transform hover:scale-[1.01]">
            <div className="bg-slate-900 p-6 text-center text-white relative overflow-hidden">
               <div className="relative z-10">
                  <div className="font-mono text-xs opacity-60 mb-1">MEMBER ID: HF-8829-AL</div>
                  <h2 className="text-2xl font-bold">Adrian Lim</h2>
                  <div className="text-teal-400 font-medium text-sm mt-1">Founder Access • All Locations</div>
               </div>
               <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
            </div>

            <div className="p-8 flex flex-col items-center bg-white relative">
               <div className="w-64 h-64 bg-slate-50 rounded-xl mb-6 p-4 border-2 border-dashed border-slate-200 flex items-center justify-center relative">
                  <img 
                     src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=HiveFlexPro-Auth-Token-12345" 
                     alt="Access QR" 
                     className="w-full h-full mix-blend-multiply opacity-90"
                  />
                  <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-colors pointer-events-none"></div>
               </div>
               
               <div className="flex items-center gap-2 text-slate-400 text-xs animate-pulse">
                  <Clock size={12} />
                  <span>Code refreshes in 04:59</span>
               </div>
            </div>

            {/* Quick Actions Footer */}
            <div className="bg-slate-50 p-4 grid grid-cols-2 divide-x divide-slate-200">
               <button 
                  onClick={() => setShowGuestModal(true)}
                  className="flex flex-col items-center justify-center gap-1 text-slate-600 hover:text-teal-600 transition-colors active:scale-95"
               >
                  <Share2 size={18} />
                  <span className="text-xs font-medium">Guest Pass</span>
               </button>
               <button className="flex flex-col items-center justify-center gap-1 text-slate-600 hover:text-teal-600 transition-colors active:scale-95">
                  <Wifi size={18} />
                  <span className="text-xs font-medium">Get Wi-Fi</span>
               </button>
            </div>
         </div>
      </div>

      <div className="bg-teal-50 border border-teal-100 rounded-xl p-4">
         <div className="flex justify-between items-center mb-2">
            <span className="text-xs font-bold text-teal-800 uppercase">Current Network</span>
            <span className="w-2 h-2 bg-green-500 rounded-full"></span>
         </div>
         <div className="flex justify-between items-end">
            <div>
               <div className="font-mono font-bold text-teal-900 text-lg">HiveFlex_Secure_5G</div>
               <div className="font-mono text-teal-700 text-sm">Pass: ScaleUp2024!</div>
            </div>
            <button className="bg-white p-2 rounded-lg text-teal-600 shadow-sm hover:scale-105 transition-transform active:scale-95">
               <Copy size={16} />
            </button>
         </div>
      </div>

      {/* Guest Pass Modal */}
      {showGuestModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <div 
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" 
                onClick={() => setShowGuestModal(false)}
            />
            <div className="relative bg-white rounded-3xl w-full max-w-sm p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200 border border-slate-100">
                <button 
                    onClick={() => setShowGuestModal(false)}
                    className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-colors"
                >
                    <X size={20} />
                </button>

                {status === 'SUCCESS' ? (
                    <div className="flex flex-col items-center justify-center py-8 text-center animate-in fade-in slide-in-from-bottom-4 duration-300">
                        <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mb-6 ring-8 ring-green-50/50">
                            <CheckCircle2 size={40} />
                        </div>
                        <h3 className="text-2xl font-bold text-slate-900 mb-2">Invite Sent!</h3>
                        <p className="text-slate-500 text-sm leading-relaxed max-w-[200px]">
                            A digital pass has been securely emailed to <br/>
                            <span className="font-semibold text-slate-900">{guestEmail}</span>
                        </p>
                    </div>
                ) : (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-200">
                        <div className="mb-6">
                            <div className="flex items-center gap-2 mb-1">
                                <div className="p-2 bg-teal-50 rounded-lg text-teal-600">
                                    <Sparkles size={18} />
                                </div>
                                <h2 className="text-xl font-bold text-slate-900">Invite a Guest</h2>
                            </div>
                            <p className="text-slate-500 text-sm">Generate a temporary QR pass for your client or partner.</p>
                        </div>

                        <div className="space-y-5">
                            <div>
                                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Guest Name</label>
                                <div className="relative group">
                                    <User className="absolute left-3 top-3 text-slate-400 group-focus-within:text-teal-500 transition-colors" size={18} />
                                    <input 
                                        type="text" 
                                        value={guestName}
                                        onChange={e => setGuestName(e.target.value)}
                                        placeholder="e.g. Sarah Tan"
                                        className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-10 pr-4 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all placeholder:text-slate-400"
                                        autoFocus
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
                                <div className="relative group">
                                    <Mail className="absolute left-3 top-3 text-slate-400 group-focus-within:text-teal-500 transition-colors" size={18} />
                                    <input 
                                        type="email" 
                                        value={guestEmail}
                                        onChange={e => setGuestEmail(e.target.value)}
                                        placeholder="e.g. sarah@partner.com"
                                        className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-10 pr-4 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all placeholder:text-slate-400"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Access Duration</label>
                                <div className="grid grid-cols-3 gap-3">
                                    {[
                                        { id: '1h', label: '1 Hour' },
                                        { id: '4h', label: 'Half Day' },
                                        { id: '1d', label: 'Full Day' }
                                    ].map(opt => (
                                        <button
                                            key={opt.id}
                                            onClick={() => setDuration(opt.id)}
                                            className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                                                duration === opt.id 
                                                ? 'bg-slate-900 text-white border-slate-900 shadow-lg shadow-slate-900/20 scale-105' 
                                                : 'bg-white text-slate-500 border-slate-200 hover:border-teal-500 hover:text-teal-600'
                                            }`}
                                        >
                                            {opt.label}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <button 
                                onClick={handleSendInvite}
                                disabled={!guestName || !guestEmail || status === 'SENDING'}
                                className="w-full bg-teal-600 hover:bg-teal-700 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed text-white py-3.5 rounded-xl font-bold mt-2 flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-teal-600/20"
                            >
                                {status === 'SENDING' ? (
                                    <><Loader2 size={18} className="animate-spin" /> Generating Pass...</>
                                ) : (
                                    <>Generate & Send Pass</>
                                )}
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
      )}
    </div>
  );
};