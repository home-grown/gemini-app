import React, { useState } from 'react';
import { ArrowRight, Lock, Mail, Loader2, ShieldCheck } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('adrian.lim@hivetech.sg');
  const [password, setPassword] = useState('password123');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate network request
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1200);
  };

  const HiveLogo = ({ className = "w-10 h-10" }: { className?: string }) => (
    <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <g transform="translate(5, 5) scale(0.9)">
        <path d="M25 25 L46.65 37.5 V62.5 L25 75 L3.35 62.5 V37.5 Z" fill="#0f172a" stroke="#1e293b" strokeWidth="2"/>
        <path d="M46.65 12.5 L68.3 25 V50 L46.65 62.5 L25 50 V25 Z" fill="#1e293b" stroke="#334155" strokeWidth="2"/>
        <path d="M68.3 25 L89.95 37.5 V62.5 L68.3 75 L46.65 62.5 V37.5 Z" fill="#fbbf24" stroke="#d97706" strokeWidth="2"/>
        <path d="M46.65 62.5 L68.3 75 V100 L46.65 112.5 L25 100 V75 Z" fill="#0f172a" stroke="#1e293b" strokeWidth="2"/>
        <circle cx="46.65" cy="62.5" r="5" fill="white" className="animate-pulse" />
        <circle cx="68.3" cy="25" r="3" fill="#0f172a" stroke="#fbbf24" strokeWidth="1" />
        <circle cx="25" cy="50" r="3" fill="#334155" />
      </g>
    </svg>
  );

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-teal-600/20 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-amber-500/10 rounded-full blur-[120px]"></div>
      </div>

      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-500">
        <div className="p-8 md:p-10">
          <div className="flex justify-center mb-8">
            <HiveLogo className="w-16 h-16" />
          </div>
          
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-slate-900">Welcome back, Adrian</h1>
            <p className="text-slate-500 mt-2 text-sm">Enter your credentials to access your workspace.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Email</label>
              <div className="relative group">
                <Mail className="absolute left-3 top-3 text-slate-400 group-focus-within:text-teal-600 transition-colors" size={18} />
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 font-medium rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                  placeholder="name@company.com"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Password</label>
              <div className="relative group">
                <Lock className="absolute left-3 top-3 text-slate-400 group-focus-within:text-teal-600 transition-colors" size={18} />
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 font-medium rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs mt-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="rounded border-slate-300 text-teal-600 focus:ring-teal-500" defaultChecked />
                <span className="text-slate-600">Remember me</span>
              </label>
              <a href="#" className="text-teal-600 hover:text-teal-700 font-medium">Forgot password?</a>
            </div>

            <button 
              type="submit" 
              disabled={isLoading}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all mt-4 shadow-lg shadow-slate-900/20 active:scale-95"
            >
              {isLoading ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <>Sign In <ArrowRight size={18} /></>
              )}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col items-center gap-3">
             <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-50 px-3 py-1.5 rounded-full">
                <ShieldCheck size={14} className="text-green-500" />
                <span>Secure Enterprise Login</span>
             </div>
             <p className="text-[10px] text-slate-400">By continuing, you agree to HiveTech's Terms of Service.</p>
          </div>
        </div>
      </div>
    </div>
  );
};