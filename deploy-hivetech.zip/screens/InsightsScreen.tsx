import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { INSIGHTS_DATA } from '../constants';
import { TrendingUp, AlertCircle, CheckCircle2, ChevronRight } from 'lucide-react';

export const InsightsScreen: React.FC = () => {
  return (
    <div className="space-y-8 pb-24 md:pb-8">
       <div>
          <h1 className="text-2xl font-bold text-slate-900">Workspace Insights</h1>
          <p className="text-slate-500">Track usage and optimize your plan.</p>
       </div>

       {/* Key Metrics */}
       <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
             <div className="text-slate-500 text-xs font-medium uppercase mb-1">Total Spend (Nov)</div>
             <div className="text-2xl font-bold text-slate-900">$4,100</div>
             <div className="flex items-center gap-1 text-xs text-red-500 mt-2">
                <TrendingUp size={12} /> +12% vs last month
             </div>
          </div>
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
             <div className="text-slate-500 text-xs font-medium uppercase mb-1">Utilization</div>
             <div className="text-2xl font-bold text-slate-900">92%</div>
             <div className="flex items-center gap-1 text-xs text-green-500 mt-2">
                <CheckCircle2 size={12} /> Optimal Range
             </div>
          </div>
       </div>

       {/* Utilization Chart */}
       <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-900 mb-6">Monthly Utilization Trend</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={INSIGHTS_DATA}>
                  <defs>
                     <linearGradient id="colorUtil" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0d9488" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#0d9488" stopOpacity={0}/>
                     </linearGradient>
                  </defs>
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#94a3b8'}} />
                  <YAxis hide />
                  <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  <Area type="monotone" dataKey="utilization" stroke="#0d9488" fillOpacity={1} fill="url(#colorUtil)" strokeWidth={3} />
               </AreaChart>
            </ResponsiveContainer>
          </div>
       </div>

       {/* Cost Chart */}
       <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-900 mb-6">Spend Analysis</h3>
          <div className="h-48">
             <ResponsiveContainer width="100%" height="100%">
                <BarChart data={INSIGHTS_DATA}>
                   <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#94a3b8'}} />
                   <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '12px', border: 'none' }} />
                   <Bar dataKey="spend" fill="#0f172a" radius={[4, 4, 0, 0]} />
                </BarChart>
             </ResponsiveContainer>
          </div>
       </div>

       {/* AI Suggestion */}
       <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex gap-4">
          <AlertCircle className="text-amber-600 shrink-0" />
          <div>
             <h4 className="font-bold text-amber-900 text-sm">Scale Up Recommended</h4>
             <p className="text-amber-700 text-xs mt-1 leading-relaxed">
                Based on your 92% utilization in November, we recommend upgrading to the <strong>Growth Plan</strong> to add 3 more flexible desk credits.
             </p>
             <button className="mt-3 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold py-2 px-4 rounded-lg transition-colors">
                View Upgrade Options
             </button>
          </div>
       </div>

       {/* Scale Controls */}
       <div className="bg-slate-900 text-white rounded-3xl p-6 relative overflow-hidden group cursor-pointer hover:shadow-2xl transition-all">
          <div className="relative z-10">
             <h2 className="text-xl font-bold mb-2">Needs have changed?</h2>
             <p className="text-slate-400 text-sm mb-4">Instantly add meeting room credits or switch to a private suite for your growing team.</p>
             <div className="flex items-center text-teal-400 text-sm font-bold">
                Manage Subscription <ChevronRight size={16} />
             </div>
          </div>
          {/* Decorative */}
          <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-teal-500 rounded-full blur-[60px] opacity-20 group-hover:opacity-30 transition-opacity"></div>
       </div>
    </div>
  );
};
