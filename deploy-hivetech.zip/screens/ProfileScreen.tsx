import React, { useState } from 'react';
import { Camera, Mail, Briefcase, MapPin, Save, Loader2, Link as LinkIcon, Github, Linkedin, Check } from 'lucide-react';

export const ProfileScreen: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  
  // Pre-filled Adrian data
  const [formData, setFormData] = useState({
    name: 'Adrian Lim',
    role: 'Founder & CTO',
    company: 'HiveTech Solutions',
    email: 'adrian.lim@hivetech.sg',
    location: 'Singapore, SG',
    bio: 'Building the future of flexible workspaces. Passionate about AI, automation, and empowering SME founders.',
    skills: 'React, TypeScript, AI Agents, Node.js',
    website: 'hivetech.sg'
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setIsSaved(false);
  };

  const handleSave = async () => {
    setIsLoading(true);
    // Simulate save
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
    setIsSaved(true);
    
    // Reset saved state after a few seconds
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="space-y-6 pb-24 md:pb-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">My Profile</h1>
          <p className="text-slate-500">Manage your personal information and preferences.</p>
        </div>
        <button 
          onClick={handleSave}
          disabled={isLoading || isSaved}
          className={`
            px-6 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 transition-all shadow-md
            ${isSaved 
              ? 'bg-green-500 text-white' 
              : 'bg-slate-900 text-white hover:bg-slate-800'
            }
          `}
        >
          {isLoading ? (
            <><Loader2 size={16} className="animate-spin" /> Saving...</>
          ) : isSaved ? (
            <><Check size={16} /> Saved</>
          ) : (
            <><Save size={16} /> Save Changes</>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Avatar & Basic Stats */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-teal-500 to-slate-900"></div>
            
            <div className="relative mt-8 mb-4 group cursor-pointer">
              <div className="w-28 h-28 rounded-full border-4 border-white shadow-lg overflow-hidden relative bg-slate-200">
                <img src="https://picsum.photos/200/200?random=10" alt="Adrian" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Camera size={24} className="text-white" />
                </div>
              </div>
              <div className="absolute bottom-1 right-1 bg-white p-1.5 rounded-full shadow-md text-slate-600">
                <Camera size={14} />
              </div>
            </div>

            <h2 className="text-xl font-bold text-slate-900">{formData.name}</h2>
            <p className="text-slate-500 text-sm mb-4">{formData.role}</p>

            <div className="flex gap-2 w-full">
              <button className="flex-1 bg-slate-50 hover:bg-slate-100 text-slate-600 py-2 rounded-lg text-xs font-bold transition-colors">
                View Public Profile
              </button>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="font-bold text-slate-900 mb-4 text-sm uppercase tracking-wide">Usage Stats</h3>
            <div className="space-y-4">
               <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-500">Member Since</span>
                  <span className="font-medium text-slate-900">Sep 2022</span>
               </div>
               <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-500">Total Bookings</span>
                  <span className="font-medium text-slate-900">142</span>
               </div>
               <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-500">Events Hosted</span>
                  <span className="font-medium text-slate-900">8</span>
               </div>
            </div>
          </div>
        </div>

        {/* Right Column: Edit Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Personal Information */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
             <h3 className="font-bold text-lg text-slate-900 mb-6 flex items-center gap-2">
                Personal Information
             </h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Full Name</label>
                   <input 
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-teal-500 outline-none transition-all"
                   />
                </div>
                <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Email Address</label>
                   <div className="relative">
                      <Mail className="absolute left-3 top-2.5 text-slate-400" size={16} />
                      <input 
                         name="email"
                         value={formData.email}
                         onChange={handleChange}
                         className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-teal-500 outline-none transition-all"
                      />
                   </div>
                </div>
                <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Job Title</label>
                   <div className="relative">
                      <Briefcase className="absolute left-3 top-2.5 text-slate-400" size={16} />
                      <input 
                         name="role"
                         value={formData.role}
                         onChange={handleChange}
                         className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-teal-500 outline-none transition-all"
                      />
                   </div>
                </div>
                <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Company</label>
                   <input 
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-teal-500 outline-none transition-all"
                   />
                </div>
             </div>
             
             <div className="mt-6">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Short Bio</label>
                <textarea 
                   name="bio"
                   value={formData.bio}
                   onChange={handleChange}
                   rows={3}
                   className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-teal-500 outline-none transition-all resize-none"
                />
                <p className="text-xs text-slate-400 mt-2 text-right">0 / 250 characters</p>
             </div>
          </div>

          {/* Social & Location */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
             <h3 className="font-bold text-lg text-slate-900 mb-6">Social & Location</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Location</label>
                   <div className="relative">
                      <MapPin className="absolute left-3 top-2.5 text-slate-400" size={16} />
                      <input 
                         name="location"
                         value={formData.location}
                         onChange={handleChange}
                         className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-teal-500 outline-none transition-all"
                      />
                   </div>
                </div>
                <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Website</label>
                   <div className="relative">
                      <LinkIcon className="absolute left-3 top-2.5 text-slate-400" size={16} />
                      <input 
                         name="website"
                         value={formData.website}
                         onChange={handleChange}
                         className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-teal-500 outline-none transition-all"
                      />
                   </div>
                </div>
             </div>
             
             <div className="mt-6">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Skills & Interests (Comma separated)</label>
                <input 
                   name="skills"
                   value={formData.skills}
                   onChange={handleChange}
                   className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-medium focus:ring-2 focus:ring-teal-500 outline-none transition-all"
                />
                <div className="flex flex-wrap gap-2 mt-3">
                   {formData.skills.split(',').map((skill, i) => (
                      <span key={i} className="text-xs bg-teal-50 text-teal-700 px-2 py-1 rounded-md border border-teal-100 font-medium">
                         {skill.trim()}
                      </span>
                   ))}
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};