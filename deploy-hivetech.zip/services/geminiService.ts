
import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Switched to stable flash model to prevent 404 errors
const CHAT_MODEL_NAME = 'gemini-2.5-flash';
const VIDEO_MODEL_NAME = 'veo-3.1-fast-generate-preview';

export const getSmartAssistantResponse = async (userMessage: string, context: string) => {
  if (!apiKey) {
    return "Demo Mode: API Key missing. Please configure your environment.";
  }

  try {
    const response = await ai.models.generateContent({
      model: CHAT_MODEL_NAME,
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `
                System Context: You are "HiveBot", the AI concierge for HiveTech, a premium coworking app for Adrian Lim (SME Founder).
                Your tone is professional, efficient, and slightly witty ("ATAS" but friendly).
                
                Capabilities:
                1. Booking meeting rooms and desks.
                2. Organizing networking events for the community.
                3. Finding and booking tickets for tech events.
                
                Current App Context: ${context}
                
                User Query: ${userMessage}
                
                Keep the response short (under 50 words) and action-oriented. If the user asks to organize an event, suggest a venue and a time.
              `
            }
          ]
        }
      ]
    });
    
    return response.text || "I'm having trouble connecting to the Hive. Try again?";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "System offline. Please check your connection.";
  }
};

export const generateMarketingVideo = async (imageBase64: string, promptText: string, aspectRatio: '16:9' | '9:16') => {
  // Veo requires user to select their own API Key
  // @ts-ignore - window.aistudio is injected by the environment
  if (window.aistudio && window.aistudio.hasSelectedApiKey) {
    // @ts-ignore
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
        // @ts-ignore
        await window.aistudio.openSelectKey();
    }
  }

  const base64Data = imageBase64.replace(/^data:image\/(png|jpeg|jpg);base64,/, "");

  // Helper to handle the request and potential retry for API key selection
  const makeRequest = async (attempt: number): Promise<string> => {
    // Create new instance to ensure key is fresh every time we try
    const videoAi = new GoogleGenAI({ apiKey: process.env.API_KEY });

    try {
      let operation = await videoAi.models.generateVideos({
        model: VIDEO_MODEL_NAME,
        prompt: promptText || "Cinematic, high quality, moving camera, slow motion",
        image: {
          imageBytes: base64Data,
          mimeType: 'image/png', // Veo supports standard image types
        },
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio
        }
      });

      // Poll for completion
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 5000));
        operation = await videoAi.operations.getVideosOperation({operation: operation});
      }

      const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (!videoUri) {
        throw new Error("Failed to generate video URI");
      }

      // Append key for download/playback
      return `${videoUri}&key=${process.env.API_KEY}`;
    } catch (error: any) {
      // Handle "Requested entity was not found" (404) which usually means invalid/expired key selection for Veo
      const errorMessage = error.message || JSON.stringify(error);
      
      // If we haven't retried yet and it's a 404/Not Found error, try to prompt for key again
      if ((errorMessage.includes("Requested entity was not found") || errorMessage.includes("404")) && attempt === 0) {
         // @ts-ignore
         if (window.aistudio && window.aistudio.openSelectKey) {
             // @ts-ignore
             await window.aistudio.openSelectKey();
             // Recursive retry (max 1 retry)
             return makeRequest(1);
         }
      }
      // If not a key issue or we already retried, throw the error
      throw error;
    }
  };

  return makeRequest(0);
};
