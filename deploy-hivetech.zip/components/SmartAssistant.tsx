import React, { useState, useRef, useEffect } from 'react';
import { getSmartAssistantResponse } from '../services/geminiService';
import { MessageCircle, X, Send, Sparkles, Loader2, Calendar, Users, Ticket } from 'lucide-react';

export const SmartAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'bot', text: string}[]>([
    { role: 'bot', text: "Hello Adrian. I can help you book a space, arrange a networking mixer, or find community events. What's on your mind?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const handleSend = async (text: string = input) => {
    if (!text.trim()) return;
    
    const userMsg = text;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    const reply = await getSmartAssistantResponse(userMsg, "User is currently navigating the HiveFlex Pro dashboard.");
    
    setMessages(prev => [...prev, { role: 'bot', text: reply }]);
    setIsLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSend();
  };

  const suggestions = [
    { label: "Book AI Workshop", icon: Ticket, query: "I want to book tickets for the upcoming AI Workshop." },
    { label: "Host Networking", icon: Users, query: "Help me organize a networking event for Fintech founders next Friday." },
    { label: "Reserve Boardroom", icon: Calendar, query: "Book the Boardroom Alpha for tomorrow at 2 PM." },
  ];

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-4 md:bottom-8 md:right-8 bg-teal-600 hover:bg-teal-700 text-white p-4 rounded-full shadow-xl transition-all z-50 flex items-center gap-2 group"
      >
        <Sparkles size={24} className="group-hover:animate-pulse" />
        <span className="hidden md:inline font-medium">HiveBot AI</span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-24 right-4 md:bottom-8 md:right-8 w-[90vw] md:w-96 bg-white rounded-2xl shadow-2xl border border-slate-100 z-50 flex flex-col overflow-hidden animate-in slide-in-from-bottom-5 fade-in duration-300">
      {/* Header */}
      <div className="bg-slate-900 text-white p-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Sparkles size={18} className="text-amber-400" />
          <h3 className="font-semibold">HiveBot Concierge</h3>
        </div>
        <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white">
          <X size={20} />
        </button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="h-80 overflow-y-auto p-4 bg-slate-50 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl p-3 text-sm ${
              msg.role === 'user' 
                ? 'bg-teal-600 text-white rounded-br-none' 
                : 'bg-white border border-slate-200 text-slate-700 rounded-bl-none shadow-sm'
            }`}>
              {msg.text}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-200 p-3 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-2">
              <Loader2 size={16} className="animate-spin text-teal-600" />
              <span className="text-xs text-slate-400">Thinking...</span>
            </div>
          </div>
        )}
      </div>

      {/* Suggestion Chips */}
      <div className="px-4 pb-2 bg-slate-50 flex gap-2 overflow-x-auto no-scrollbar">
        {suggestions.map((s, i) => (
            <button 
                key={i}
                onClick={() => handleSend(s.query)}
                disabled={isLoading}
                className="flex items-center gap-1 whitespace-nowrap bg-white border border-slate-200 hover:border-teal-500 hover:text-teal-600 text-slate-600 text-[10px] font-medium py-1.5 px-3 rounded-full transition-colors shadow-sm shrink-0"
            >
                <s.icon size={12} />
                {s.label}
            </button>
        ))}
      </div>

      {/* Input */}
      <div className="p-3 bg-white border-t border-slate-100 flex gap-2">
        <input 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Ask to book events or rooms..."
          className="flex-1 bg-slate-50 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-teal-500 outline-none"
        />
        <button 
          onClick={() => handleSend()}
          disabled={isLoading}
          className="bg-teal-600 hover:bg-teal-700 text-white p-2 rounded-xl transition-colors disabled:opacity-50"
        >
          <Send size={18} />
        </button>
      </div>
    </div>
  );
};