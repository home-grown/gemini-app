
import React, { useState } from 'react';
import { User, Video, Coffee, Wifi, Crown, Lock, LayoutGrid, Info } from 'lucide-react';

interface Zone {
  id: string;
  label: string;
  type: 'PRIVATE' | 'HOT_DESK' | 'PREMIUM' | 'LOUNGE';
  top: string;
  left: string;
  width: string;
  height: string;
  color: string;
}

interface Marker {
  id: string;
  type: 'PERSON' | 'ROOM' | 'AMENITY';
  top: string;
  left: string;
  label: string;
  status?: string;
  avatar?: string;
}

export const FloorPlan: React.FC = () => {
  const [showZones, setShowZones] = useState(true);
  const [activeMarker, setActiveMarker] = useState<string | null>(null);

  // Mapped based on the pixel art image provided
  const zones: Zone[] = [
    {
      id: 'z1',
      label: 'Private Suites',
      type: 'PRIVATE',
      top: '28%',
      left: '9.5%',
      width: '18%',
      height: '68%',
      color: 'bg-purple-500/10 border-purple-500/30'
    },
    {
      id: 'z2',
      label: 'Product Team',
      type: 'HOT_DESK',
      top: '22%',
      left: '30%',
      width: '32%',
      height: '35%',
      color: 'bg-blue-500/10 border-blue-500/30'
    },
    {
      id: 'z3',
      label: 'CX Team (Premium)',
      type: 'PREMIUM',
      top: '60%',
      left: '65%',
      width: '30%',
      height: '35%',
      color: 'bg-amber-500/10 border-amber-500/30'
    },
    {
      id: 'z4',
      label: 'Lounge & Breakout',
      type: 'LOUNGE',
      top: '20%',
      left: '65%',
      width: '30%',
      height: '35%',
      color: 'bg-green-500/10 border-green-500/30'
    }
  ];

  const markers: Marker[] = [
    // Left Sidebar (Private)
    { id: 'm1', type: 'ROOM', top: '35%', left: '18%', label: 'Meeting Nook', status: 'Occupied by Jinen, Steven' },
    { id: 'm2', type: 'AMENITY', top: '75%', left: '18%', label: 'Library Focus', status: 'Quiet Zone' },
    
    // Center Top (Product)
    { id: 'm3', type: 'PERSON', top: '40%', left: '35%', label: 'Brad', status: 'Deep Work', avatar: 'https://picsum.photos/50/50?random=50' },
    { id: 'm4', type: 'PERSON', top: '40%', left: '55%', label: 'Alison', status: 'In a Call', avatar: 'https://picsum.photos/50/50?random=51' },
    { id: 'm5', type: 'ROOM', top: '30%', left: '48%', label: 'Team Sync', status: 'Booked' },

    // Bottom Right (CX)
    { id: 'm6', type: 'PERSON', top: '65%', left: '70%', label: 'Morgan', status: 'Available', avatar: 'https://picsum.photos/50/50?random=52' },
    { id: 'm7', type: 'AMENITY', top: '58%', left: '78%', label: 'Coffee Station', status: 'Fresh Brew' },

    // Top Right (Lounge)
    { id: 'm8', type: 'AMENITY', top: '35%', left: '80%', label: 'Sofa Area', status: 'Casual Meeting' },

    // Bottom Center (Recreation)
    { id: 'm9', type: 'AMENITY', top: '70%', left: '46%', label: 'Ping Pong', status: 'Free' },
    { id: 'm10', type: 'AMENITY', top: '75%', left: '60%', label: 'High-Speed Wifi', status: 'Zone 5G' },
  ];

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-in fade-in duration-500">
      {/* Controls */}
      <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <LayoutGrid size={18} className="text-teal-600" /> 
          Live Floor Plan
        </h3>
        <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Show Zones</span>
            <button 
                onClick={() => setShowZones(!showZones)}
                className={`w-10 h-5 rounded-full transition-colors relative ${showZones ? 'bg-teal-600' : 'bg-slate-300'}`}
            >
                <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-transform ${showZones ? 'left-6' : 'left-1'}`}></div>
            </button>
        </div>
      </div>

      {/* Map Container */}
      <div className="relative w-full aspect-[4/3] bg-slate-100 overflow-hidden group cursor-crosshair">
        {/* Background Image Placeholder - In production this would be the actual floorplan image */}
        <div className="absolute inset-0 bg-[url('https://cdn.midjourney.com/5c98782d-4545-4202-9572-10f73c683884/0_0.png')] bg-cover bg-center opacity-90 grayscale-[0.2]"></div>
        
        {/* Fallback pattern if image fails to load or for better visibility */}
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/graphy.png')] opacity-20 pointer-events-none"></div>

        {/* Zones Layer */}
        {showZones && zones.map(zone => (
            <div 
                key={zone.id}
                style={{ top: zone.top, left: zone.left, width: zone.width, height: zone.height }}
                className={`absolute border-2 rounded-xl flex items-start justify-center pt-2 transition-all hover:opacity-80 hover:scale-[1.01] ${zone.color}`}
            >
                <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-md text-[10px] font-bold shadow-sm flex items-center gap-1 uppercase tracking-wider text-slate-700">
                    {zone.type === 'PRIVATE' && <Lock size={10} />}
                    {zone.type === 'PREMIUM' && <Crown size={10} />}
                    {zone.type === 'HOT_DESK' && <LayoutGrid size={10} />}
                    {zone.type === 'LOUNGE' && <Coffee size={10} />}
                    {zone.label}
                </div>
            </div>
        ))}

        {/* Markers Layer */}
        {markers.map(marker => (
            <div
                key={marker.id}
                style={{ top: marker.top, left: marker.left }}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 group/marker"
                onMouseEnter={() => setActiveMarker(marker.id)}
                onMouseLeave={() => setActiveMarker(null)}
            >
                {/* Marker Icon */}
                <button className={`
                    w-8 h-8 rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-transform hover:scale-110
                    ${marker.type === 'PERSON' ? 'bg-indigo-500 text-white' : ''}
                    ${marker.type === 'ROOM' ? 'bg-rose-500 text-white' : ''}
                    ${marker.type === 'AMENITY' ? 'bg-teal-500 text-white' : ''}
                `}>
                    {marker.type === 'PERSON' && (marker.avatar ? <img src={marker.avatar} className="w-full h-full rounded-full object-cover" /> : <User size={14} />)}
                    {marker.type === 'ROOM' && <Video size={14} />}
                    {marker.type === 'AMENITY' && <Wifi size={14} />}
                    
                    {/* Badge */}
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                </button>

                {/* Tooltip */}
                <div className={`
                    absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-32 bg-slate-900 text-white text-xs rounded-lg py-2 px-3 shadow-xl z-10 pointer-events-none transition-all
                    ${activeMarker === marker.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}
                `}>
                    <div className="font-bold mb-0.5">{marker.label}</div>
                    <div className="text-slate-400 text-[10px]">{marker.status}</div>
                    <div className="absolute bottom-[-4px] left-1/2 -translate-x-1/2 w-2 h-2 bg-slate-900 rotate-45"></div>
                </div>
            </div>
        ))}

        {/* User Location Marker */}
        <div className="absolute top-[15%] left-[15%] flex flex-col items-center animate-bounce duration-[2000ms]">
            <div className="bg-slate-900 text-white text-[10px] font-bold px-2 py-0.5 rounded-full mb-1 shadow-sm">You</div>
            <div className="w-4 h-4 bg-slate-900 rounded-full border-2 border-white shadow-md"></div>
        </div>

      </div>

      {/* Legend */}
      <div className="bg-slate-50 p-3 flex flex-wrap gap-4 justify-center border-t border-slate-100">
         <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span className="w-2 h-2 rounded-full bg-indigo-500"></span> Colleagues
         </div>
         <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span className="w-2 h-2 rounded-full bg-rose-500"></span> Meeting Rooms
         </div>
         <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span className="w-2 h-2 rounded-full bg-teal-500"></span> Amenities
         </div>
         <div className="h-4 w-px bg-slate-300 mx-2"></div>
         <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <Crown size={12} className="text-amber-500" /> Premium
         </div>
         <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <Lock size={12} className="text-purple-500" /> Private
         </div>
      </div>
    </div>
  );
};
