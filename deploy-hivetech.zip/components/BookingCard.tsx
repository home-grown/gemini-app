import React from 'react';
import { Space } from '../types';
import { Users, Wifi, Monitor, Coffee, ArrowRight } from 'lucide-react';

interface BookingCardProps {
  space: Space;
  onBook: (space: Space) => void;
}

export const BookingCard: React.FC<BookingCardProps> = ({ space, onBook }) => {
  return (
    <div className="group bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all border border-slate-100 overflow-hidden">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={space.image} 
          alt={space.name} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-slate-900 shadow-sm">
          ${space.pricePerHour}/hr
        </div>
        {space.type === 'MEETING_ROOM' && (
          <div className="absolute bottom-3 left-3 bg-slate-900/80 backdrop-blur-sm text-white px-2 py-1 rounded-md text-xs flex items-center gap-1">
             <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
             360° View Available
          </div>
        )}
      </div>
      
      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="font-bold text-lg text-slate-900">{space.name}</h3>
            <p className="text-slate-500 text-sm flex items-center gap-1">
              {space.location}
            </p>
          </div>
          <div className="flex items-center gap-1 text-slate-600 bg-slate-50 px-2 py-1 rounded-lg">
            <Users size={14} />
            <span className="text-xs font-medium">{space.capacity}</span>
          </div>
        </div>

        <div className="flex gap-3 my-4">
          {space.amenities.includes('Video Conf') && <Monitor size={16} className="text-slate-400" />}
          {space.amenities.includes('Coffee') && <Coffee size={16} className="text-slate-400" />}
          <Wifi size={16} className="text-slate-400" />
        </div>

        <button 
          onClick={() => onBook(space)}
          className="w-full bg-slate-900 text-white py-3 rounded-xl text-sm font-medium hover:bg-slate-800 flex items-center justify-center gap-2 transition-colors active:scale-95"
        >
          Book Now <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
};
