
import React, { useState } from 'react';
import { Bell, MessageCircle, Calendar, CheckCircle2, AlertCircle, X } from 'lucide-react';
import { Notification } from '../types';
import { MOCK_NOTIFICATIONS } from '../constants';

export const Notifications: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>(MOCK_NOTIFICATIONS);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const handleMarkAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'EVENT': return <Calendar size={16} className="text-purple-500" />;
      case 'CHAT': return <MessageCircle size={16} className="text-teal-500" />;
      case 'SYSTEM': return <CheckCircle2 size={16} className="text-green-500" />;
      case 'ALERT': return <AlertCircle size={16} className="text-amber-500" />;
      default: return <Bell size={16} className="text-slate-500" />;
    }
  };

  const getBgColor = (type: string) => {
    switch (type) {
        case 'EVENT': return 'bg-purple-50';
        case 'CHAT': return 'bg-teal-50';
        case 'SYSTEM': return 'bg-green-50';
        case 'ALERT': return 'bg-amber-50';
        default: return 'bg-slate-50';
    }
  };

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all"
      >
        <Bell size={24} />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 border-2 border-white rounded-full"></span>
        )}
      </button>

      {isOpen && (
        <>
            <div 
                className="fixed inset-0 z-30" 
                onClick={() => setIsOpen(false)}
            />
            <div className="absolute right-0 mt-2 w-80 md:w-96 bg-white rounded-2xl shadow-2xl border border-slate-100 z-40 overflow-hidden animate-in fade-in zoom-in-95 duration-200 origin-top-right">
                <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                    <div>
                        <h3 className="font-bold text-slate-900">Notifications</h3>
                        <p className="text-xs text-slate-500">{unreadCount} unread alerts</p>
                    </div>
                    {unreadCount > 0 && (
                        <button 
                            onClick={handleMarkAsRead}
                            className="text-xs font-bold text-teal-600 hover:text-teal-700"
                        >
                            Mark all read
                        </button>
                    )}
                </div>

                <div className="max-h-[400px] overflow-y-auto">
                    {notifications.length === 0 ? (
                        <div className="p-8 text-center text-slate-400 text-sm">
                            No notifications yet.
                        </div>
                    ) : (
                        notifications.map((notif) => (
                            <div 
                                key={notif.id}
                                className={`p-4 border-b border-slate-50 hover:bg-slate-50 transition-colors flex gap-3 ${!notif.isRead ? 'bg-slate-50/50' : ''}`}
                            >
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${getBgColor(notif.type)}`}>
                                    {getIcon(notif.type)}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-start mb-1">
                                        <h4 className={`text-sm font-semibold truncate ${!notif.isRead ? 'text-slate-900' : 'text-slate-600'}`}>
                                            {notif.title}
                                        </h4>
                                        <span className="text-[10px] text-slate-400 whitespace-nowrap ml-2">{notif.time}</span>
                                    </div>
                                    <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">
                                        {notif.message}
                                    </p>
                                </div>
                                {!notif.isRead && (
                                    <div className="w-2 h-2 rounded-full bg-teal-500 mt-2"></div>
                                )}
                            </div>
                        ))
                    )}
                </div>
            </div>
        </>
      )}
    </div>
  );
};
